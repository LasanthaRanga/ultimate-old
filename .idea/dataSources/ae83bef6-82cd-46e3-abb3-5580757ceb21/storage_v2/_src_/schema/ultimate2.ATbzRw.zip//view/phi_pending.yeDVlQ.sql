create view phi_pending as
select `ultimate2`.`application`.`idApplication`     AS `idApplication`,
       `ultimate2`.`application`.`application_no`    AS `application_no`,
       `ultimate2`.`application`.`application_date`  AS `application_date`,
       `ultimate2`.`application`.`trade_name`        AS `trade_name`,
       `ultimate2`.`application`.`cus_name`          AS `cus_name`,
       `ultimate2`.`application`.`cus_nic`           AS `cus_nic`,
       `ultimate2`.`assessment`.`assessment_no`      AS `assessment_no`,
       `ultimate2`.`street`.`street_name`            AS `street_name`,
       `ultimate2`.`ward`.`ward_no`                  AS `ward_no`,
       `ultimate2`.`application`.`approveTo_Paymant` AS `approveTo_Paymant`,
       `ultimate2`.`sr_flow`.`sr_flow_name`          AS `sr_flow_name`,
       `ultimate2`.`sr_building`.`sr_building_name`  AS `sr_building_name`,
       `ultimate2`.`sr_shop`.`sr_shop_no`            AS `sr_shop_no`,
       `ultimate2`.`apprualstatues`.`idOtheritisCat` AS `idOtheritisCat`,
       `ultimate2`.`approval_cat`.`approval_name`    AS `approval_name`
from ((((((((`ultimate2`.`application` join `ultimate2`.`apprualstatues` on ((
    `ultimate2`.`apprualstatues`.`Application_idApplication` =
    `ultimate2`.`application`.`idApplication`))) left join `ultimate2`.`assessment` on ((
    `ultimate2`.`application`.`Assessment_idAssessment` =
    `ultimate2`.`assessment`.`idAssessment`))) join `ultimate2`.`street` on ((
    `ultimate2`.`assessment`.`Street_idStreet` = `ultimate2`.`street`.`idStreet`))) join `ultimate2`.`ward` on ((
    (`ultimate2`.`assessment`.`Ward_idWard` = `ultimate2`.`ward`.`idWard`) and
    (`ultimate2`.`street`.`Ward_idWard` = `ultimate2`.`ward`.`idWard`)))) left join `ultimate2`.`sr_shop` on ((
    `ultimate2`.`application`.`sr_shop_idsr_shop` =
    `ultimate2`.`sr_shop`.`idsr_shop`))) left join `ultimate2`.`sr_flow` on ((
    `ultimate2`.`sr_shop`.`sr_flow_idsr_flow` =
    `ultimate2`.`sr_flow`.`idsr_flow`))) left join `ultimate2`.`sr_building` on ((
    (`ultimate2`.`sr_shop`.`sr_building_idsr_building` = `ultimate2`.`sr_building`.`idsr_building`) and
    (`ultimate2`.`sr_flow`.`sr_building_idsr_building` = `ultimate2`.`sr_building`.`idsr_building`))))
       join `ultimate2`.`approval_cat`
            on ((`ultimate2`.`apprualstatues`.`idOtheritisCat` = `ultimate2`.`approval_cat`.`idApproval_cat`)))
where ((`ultimate2`.`apprualstatues`.`statues` = 0) and (`ultimate2`.`apprualstatues`.`idOtheritisCat` = 12));

