create view alocationstatus1 as
select `ultimate2`.`ass_allocation`.`idass_allocation`               AS `idass_allocation`,
       `ultimate2`.`ass_allocation`.`Assessment_idAssessment`        AS `Assessment_idAssessment`,
       `ultimate2`.`ass_allocation`.`ass_allocation`                 AS `ass_allocation`,
       count(`ultimate2`.`ass_allocation`.`Assessment_idAssessment`) AS `co`
from `ultimate2`.`ass_allocation`
where (`ultimate2`.`ass_allocation`.`ass_allocation_status` = 1)
group by `ultimate2`.`ass_allocation`.`Assessment_idAssessment`;

