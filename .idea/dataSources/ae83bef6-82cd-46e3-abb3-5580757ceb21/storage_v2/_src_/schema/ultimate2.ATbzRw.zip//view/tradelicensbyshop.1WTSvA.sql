create view tradelicensbyshop as
select `ultimate2`.`application`.`idApplication`    AS `idApplication`,
       `ultimate2`.`application`.`application_no`   AS `application_no`,
       `ultimate2`.`application`.`trade_name`       AS `trade_name`,
       `ultimate2`.`application`.`cus_name`         AS `cus_name`,
       `ultimate2`.`application`.`cus_nic`          AS `cus_nic`,
       `ultimate2`.`application`.`application_date` AS `application_date`,
       `ultimate2`.`trade_type`.`type_name`         AS `type_name`,
       `ultimate2`.`sr_building`.`sr_building_name` AS `sr_building_name`,
       `ultimate2`.`sr_flow`.`sr_flow_name`         AS `sr_flow_name`,
       `ultimate2`.`sr_shop`.`sr_shop_no`           AS `sr_shop_no`
from ((((`ultimate2`.`application` join `ultimate2`.`sr_shop` on ((`ultimate2`.`application`.`sr_shop_idsr_shop` =
                                                                   `ultimate2`.`sr_shop`.`idsr_shop`))) join `ultimate2`.`sr_flow` on ((
    `ultimate2`.`sr_shop`.`sr_flow_idsr_flow` =
    `ultimate2`.`sr_flow`.`idsr_flow`))) join `ultimate2`.`sr_building` on ((
    (`ultimate2`.`sr_shop`.`sr_building_idsr_building` = `ultimate2`.`sr_building`.`idsr_building`) and
    (`ultimate2`.`sr_flow`.`sr_building_idsr_building` = `ultimate2`.`sr_building`.`idsr_building`))))
       join `ultimate2`.`trade_type`
            on ((`ultimate2`.`application`.`Trade_Type_idTrade_Type` = `ultimate2`.`trade_type`.`idTrade_Type`)))
where isnull(`ultimate2`.`application`.`Assessment_idAssessment`);

