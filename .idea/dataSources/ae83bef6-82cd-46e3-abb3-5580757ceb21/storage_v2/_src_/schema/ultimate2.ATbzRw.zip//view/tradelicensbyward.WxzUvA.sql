create view tradelicensbyward as
select `ultimate2`.`application`.`idApplication`    AS `idApplication`,
       `ultimate2`.`ward`.`ward_name`               AS `ward_name`,
       `ultimate2`.`street`.`street_name`           AS `street_name`,
       `ultimate2`.`application`.`application_no`   AS `application_no`,
       `ultimate2`.`application`.`trade_name`       AS `trade_name`,
       `ultimate2`.`application`.`cus_name`         AS `cus_name`,
       `ultimate2`.`application`.`cus_nic`          AS `cus_nic`,
       `ultimate2`.`application`.`application_date` AS `application_date`,
       `ultimate2`.`trade_type`.`type_name`         AS `type_name`,
       `ultimate2`.`assessment`.`assessment_no`     AS `assessment_no`
from (`ultimate2`.`trade_type`
       left join (((`ultimate2`.`ward` left join `ultimate2`.`street` on ((`ultimate2`.`street`.`Ward_idWard` = `ultimate2`.`ward`.`idWard`))) left join `ultimate2`.`assessment` on ((
    (`ultimate2`.`assessment`.`Street_idStreet` = `ultimate2`.`street`.`idStreet`) and
    (`ultimate2`.`assessment`.`Ward_idWard` = `ultimate2`.`ward`.`idWard`)))) left join `ultimate2`.`application` on ((
    `ultimate2`.`application`.`Assessment_idAssessment` = `ultimate2`.`assessment`.`idAssessment`)))
                 on ((`ultimate2`.`application`.`Trade_Type_idTrade_Type` = `ultimate2`.`trade_type`.`idTrade_Type`)))
order by `ultimate2`.`ward`.`idWard`;

