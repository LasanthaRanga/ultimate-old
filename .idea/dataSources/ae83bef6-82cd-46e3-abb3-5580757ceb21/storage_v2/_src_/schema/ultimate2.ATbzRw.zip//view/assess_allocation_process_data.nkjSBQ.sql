create view assess_allocation_process_data as
select `ultimate2`.`assessment`.`idAssessment`                                      AS `idAssessment`,
       `ultimate2`.`assessment`.`Customer_idCustomer`                               AS `Customer_idCustomer`,
       `ultimate2`.`assessment`.`Ward_idWard`                                       AS `Ward_idWard`,
       `ultimate2`.`assessment`.`Street_idStreet`                                   AS `Street_idStreet`,
       `ultimate2`.`assessment`.`ass_nature_idass_nature`                           AS `ass_nature_idass_nature`,
       `ultimate2`.`assessment`.`ass_discription_idass_discription`                 AS `ass_discription_idass_discription`,
       `ultimate2`.`assessment`.`User_idUser`                                       AS `User_idUser`,
       `ultimate2`.`assessment`.`assessment_oder`                                   AS `assessment_oder`,
       `ultimate2`.`assessment`.`assessment_no`                                     AS `assessment_no`,
       `ultimate2`.`assessment`.`assessment_status`                                 AS `assessment_status`,
       `ultimate2`.`assessment`.`assessment_syn`                                    AS `assessment_syn`,
       `ultimate2`.`assessment`.`assessment_comment`                                AS `assessment_comment`,
       `ultimate2`.`assessment`.`assessment_obsolete`                               AS `assessment_obsolete`,
       `ultimate2`.`ass_allocation`.`idass_allocation`                              AS `idass_allocation`,
       `ultimate2`.`ass_allocation`.`ass_allocation`                                AS `ass_allocation`,
       `ultimate2`.`ass_allocation`.`ass_allocation_status`                         AS `ass_allocation_status`,
       `ultimate2`.`ass_allocation`.`ass_allocation_change_date`                    AS `ass_allocation_change_date`,
       `ultimate2`.`ass_allocation`.`ass_allocation_discription`                    AS `ass_allocation_discription`,
       `ultimate2`.`ass_allocation`.`ass_allocation_idUser`                         AS `ass_allocation_idUser`,
       `ultimate2`.`assessment_has_processtype`.`Processtype_idProcesstype`         AS `Processtype_idProcesstype`,
       `ultimate2`.`assessment_has_processtype`.`Assessment_has_Processtype_date`   AS `Assessment_has_Processtype_date`,
       `ultimate2`.`assessment_has_processtype`.`Assessment_has_Processtype_status` AS `Assessment_has_Processtype_status`,
       `ultimate2`.`processtype`.`idProcesstype`                                    AS `idProcesstype`,
       `ultimate2`.`processtype`.`Processtype_name`                                 AS `Processtype_name`,
       `ultimate2`.`assessment_has_processtype`.`idAssessment_has_Processtype`      AS `idAssessment_has_Processtype`
from (((`ultimate2`.`assessment` left join `ultimate2`.`ass_allocation` on ((
    `ultimate2`.`ass_allocation`.`Assessment_idAssessment` =
    `ultimate2`.`assessment`.`idAssessment`))) left join `ultimate2`.`assessment_has_processtype` on ((
    `ultimate2`.`assessment_has_processtype`.`Assessment_idAssessment` = `ultimate2`.`assessment`.`idAssessment`)))
       left join `ultimate2`.`processtype` on ((`ultimate2`.`assessment_has_processtype`.`Processtype_idProcesstype` =
                                                `ultimate2`.`processtype`.`idProcesstype`)))
where ((`ultimate2`.`ass_allocation`.`ass_allocation_status` = 1) and
       (`ultimate2`.`assessment_has_processtype`.`Assessment_has_Processtype_status` = 1) and
       (`ultimate2`.`assessment`.`assessment_syn` = 0));

