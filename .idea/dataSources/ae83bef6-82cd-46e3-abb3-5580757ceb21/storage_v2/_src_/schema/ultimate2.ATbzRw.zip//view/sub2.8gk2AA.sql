create view sub2 as
select `ultimate2`.`ass_subowner`.`idass_subOwner`          AS `idass_subOwner`,
       `ultimate2`.`ass_subowner`.`ass_subOwner_name`       AS `ass_subOwner_name`,
       `ultimate2`.`ass_subowner`.`ass_subOwner_nic`        AS `ass_subOwner_nic`,
       `ultimate2`.`ass_subowner`.`ass_subOwner_status`     AS `ass_subOwner_status`,
       `ultimate2`.`ass_subowner`.`Assessment_idAssessment` AS `Assessment_idAssessment`
from `ultimate2`.`ass_subowner`;

